// register client system
var system = server.registerSystem(0, 0);

var game = {};
game.started = false;
game.startItem = "bedrock";

game.setup = false;
game.setupTimer = 50;

game.players = [];
game.playerNum = 0;
game.locations = [];
game.timer;
game.gracePeriod = 600; // 30 seconds
game.randomTime = 2400; // 120 seconds of randomized time;

var spread = {}
spread.centerX = 0;
spread.centerZ = 0;
spread.distance = 500;
spread.range = 2000;

var entityQuery = {};
var time = 0;

system.initialize = function () {
    //register event data, register components, register queries, listen for events
    this.listenForEvent("minecraft:entity_dropped_item", (eventData) => this.onItemDrop(eventData));
    this.listenForEvent("minecraft:entity_death", (eventData) => this.onEntityDeath(eventData));
    entityQuery = this.registerQuery();
};

system.update = function () {
    //Update all the things
    if (game.setup) {
        if (game.setupTimer <= 0) {
            game.setup = false;
            game.started = true;
            this.groundPlayers();
        } else {
            game.setupTimer--;
        }
    }

    if (game.started) {
        if (game.playerNum <= 1) {
            this.endgame();
        } else if (game.timer <= 0) {
            game.timer = game.gracePeriod + Math.floor(Math.random() * game.randomTime);
            this.swap();
        } else {
            game.timer--;
        }
    }
};

system.shutdown = function () {
    //Cleanup script only things
};

system.commandCallback = function (commandResultData) {
    //Used to debug command calls
    // let eventData = this.createEventData("minecraft:display_chat_event");
    // if (eventData) {
    // 	eventData.data.message = message;
    // 	this.broadcastEvent("minecraft:display_chat_event", "Callback called! Command: " + commandResultData.command + " Data: " + JSON.stringify(commandResultData.data, null, "    ") );
    // }
};

// check if game is to be started
system.onItemDrop = function (eventData) {
    // let item = eventData.data.item_stack;
    let item = eventData.data.item_stack;

    if (item.item == `minecraft:${game.startItem}`) {
        this.startGame();
    }
}

// eliminate players if they died
system.onEntityDeath = function (eventData) {
    let died = eventData.data.entity;
    if (game.started && died.__identifier__ == "minecraft:player") {
        this.eliminatePlayer(died);
    }
}

system.eliminatePlayer = function (player) {
    let playerName = this.getName(player);
    let len = game.players.length;
    let playerElimed = false;
    for (let i = 0; i < len; i++) {
        if (this.getName(game.players[i]) == playerName) {
            game.players.splice(i, 1);
            playerElimed = true;
        }
    }
    if (playerElimed) {
        game.playerNum--;
        this.executeCommand(`/say eliminated ${playerName}`, (commandResultData) => this.commandCallback(commandResultData));
        this.executeCommand(`/op ${playerName}`, (commandResultData) => this.commandCallback(commandResultData));
    }
}

system.updateTimer = function () {
    if (game.timer % 10 == 0) {
        this.executeCommand(`/say swap in ${game.timer}`, (commandResultData) => this.commandCallback(commandResultData));
    }
    game.timer--;
}

system.swap = function () {
    let from;
    let to;
    this.executeCommand(`/say num of players ${game.playerNum}`, (commandResultData) => this.commandCallback(commandResultData));
    [from, to] = pair(game.playerNum);

    for (let i = 0; i < game.playerNum; i++) {
        let name = this.getName(game.players[from[i]]);

        let pos = this.getPos(game.players[to[i]]);

        // executed at end of frame, shouldn't be an issue.
        this.executeCommand(`/tp ${name} ${pos.x} ${pos.y} ${pos.z}`,
            (commandResultData) => this.commandCallback(commandResultData));
    }
}

system.startGame = function () {

    game.started = true;
    game.timer = game.gracePeriod + Math.floor(Math.random() * game.randomTime);

    game.players = this.getAllPlayers();
    game.playerNum = game.players.length;

    let outputPlayerList = ""
    for (let index = 0; index < game.playerNum; index++) {
        let name = this.getName(game.players[index]);
        outputPlayerList += name + ", ";
    }
    this.executeCommand(`/say Players: ${outputPlayerList}`, (commandResultData) => this.commandCallback(commandResultData));

    this.executeCommand(`/kill @e [type=item, name=${game.startItem}]`, (commandResultData) => this.commandCallback(commandResultData));

    this.spreadPlayers();

    // set timer
}

system.endgame = function () {
    let winner = game.players[0];
    this.executeCommand(`/say ${this.getName(winner)} won the game`, (commandResultData) => this.commandCallback(commandResultData));

    // reset variables
    game.started = false;
    game.setup = false;
    game.setupTimer = 60;
    
    game.players = [];
    game.playerNum = 0;
}

system.spreadPlayers = function () {
    this.executeCommand(`/effect @a slow_falling 1 5 true`,
        (commandResultData) => this.commandCallback(commandResultData))
    this.executeCommand(`/effect @a resistance 10 5 true`,
        (commandResultData) => this.commandCallback(commandResultData))
    this.executeCommand(`/spreadplayers ${spread.centerX} ${spread.centerZ} ${spread.distance} ${spread.range} @a`,
        (commandResultData) => this.commandCallback(commandResultData));
}

system.groundPlayers = function () {
    // for (let i = 0; i < game.playerNum; i++) {
    //     let pos = this.getPos(game.players[i]);
    //     let name = this.getName(game.players[i]);
    //     this.executeCommand(`/spreadplayers ${pos.x} ${pos.z} 0 100 ${name}`,
    //         (commandResultData) => this.commandCallback(commandResultData));
    // }
}

// helpers
system.getPos = function (entity) {
    return this.getComponent(entity, "minecraft:position").data;
}

system.getName = function (entity) {
    return this.getComponent(entity, "minecraft:nameable").data.name;
}

system.getAllPlayers = function () {
    var players = [];
    let entities = this.getEntitiesFromQuery(entityQuery);
    let size = entities.length;
    for (let index = 0; index < size; index++) {
        if (entities[index].__identifier__ == "minecraft:player") {
            players.push(entities[index]);
        }
    }
    return players;
}

function pair(n) {
    let from = []
    let to = []
    for (let i = 0; i < n; i++) {
        from.push(i)
    }
    from = shuffle(from);
    to.push(from[n - 1]);
    for (let i = 1; i < n; i++) {
        to.push(from[n])
    }
    return [from, to]
}

function shuffle(a) {
    let j, x, i;
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
    return a;
}